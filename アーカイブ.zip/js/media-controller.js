/**
 * メディアコントローラー (Spotify / YouTube 切り替え)
 */
(function() {
/** @type {number|null} メディア状態のポーリングインターバルID */
let mediaPollInterval = null;

window.initMediaController = initMediaController;

/**
 * メディアコントローラーの初期化処理
 */
function initMediaController() {
    configureYouTubeAvailability();
    setupMediaModeSettings();
    applyMediaMode();

    const mediaRadios = document.querySelectorAll('input[name="media-mode"]');
    mediaRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            localStorage.setItem(STORAGE_KEY_MEDIA_MODE, radio.value);
            applyMediaMode();
        });
    });

    const playBtn = document.getElementById('spotify-play-btn');
    const nextBtn = document.getElementById('spotify-next-btn');
    const prevBtn = document.getElementById('spotify-prev-btn');

    if (playBtn) {
        playBtn.addEventListener('click', (e) => {
            if (getMediaMode() === 'youtube') {
                e.stopImmediatePropagation();
                toggleYouTubePlay();
            }
        }, true);
    }

    if (nextBtn) {
        nextBtn.addEventListener('click', (e) => {
            if (getMediaMode() === 'youtube') {
                e.stopImmediatePropagation();
                controlYouTube('next');
            }
        }, true);
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', (e) => {
            if (getMediaMode() === 'youtube') {
                e.stopImmediatePropagation();
                controlYouTube('prev');
            }
        }, true);
    }
}

/**
 * YouTubeの制御が可能かどうかを判定する
 * @returns {boolean} 制御可能な場合はtrue
 */
function canControlYouTube() {
    return Boolean(
        typeof chrome !== 'undefined' &&
        chrome.tabs?.query &&
        chrome.scripting?.executeScript
    );
}

/**
 * YouTube連携の利用可能性を設定し、UIに反映する
 */
function configureYouTubeAvailability() {
    const youtubeRadio = document.querySelector('input[name="media-mode"][value="youtube"]');
    if (!youtubeRadio || canControlYouTube()) return;

    youtubeRadio.disabled = true;
    youtubeRadio.title = 'このビルドにはYouTube操作に必要なscripting権限がありません。';
    const label = youtubeRadio.closest('label');
    if (label) {
        label.title = youtubeRadio.title;
        label.style.opacity = '0.55';
        label.style.cursor = 'not-allowed';
    }

    if (getMediaMode() === 'youtube') {
        localStorage.setItem(STORAGE_KEY_MEDIA_MODE, 'spotify');
        window.showNotification?.('YouTube操作は必要な拡張権限がないためSpotifyへ戻しました。', 'warning');
    }
}

/**
 * 現在のメディアモードを取得する
 * @returns {string} 'spotify' または 'youtube'
 */
function getMediaMode() {
    return localStorage.getItem(STORAGE_KEY_MEDIA_MODE) || 'spotify';
}

/**
 * メディアモードの設定UIを初期化する
 */
function setupMediaModeSettings() {
    const stored = getMediaMode();
    const radio = document.querySelector(`input[name="media-mode"][value="${stored}"]`);
    if (radio) radio.checked = true;
}

/**
 * 現在のメディアモードをUIと状態に適用する
 */
function applyMediaMode() {
    const mode = getMediaMode();
    const widgetHeader = document.querySelector('#spotify-widget .widget-header span');
    const spotifyAuthPrompt = document.getElementById('spotify-auth-prompt');
    const spotifyPlayerContainer = document.getElementById('spotify-player-container');
    const spotifyLogoutBtn = document.getElementById('spotify-logout-btn');

    if (mediaPollInterval) {
        clearInterval(mediaPollInterval);
        mediaPollInterval = null;
    }

    if (mode === 'youtube') {
        if (widgetHeader) widgetHeader.textContent = 'YouTube プレイヤー';
        
        if (spotifyAuthPrompt) spotifyAuthPrompt.style.setProperty('display', 'none', 'important');
        if (spotifyPlayerContainer) spotifyPlayerContainer.style.setProperty('display', 'flex', 'important');
        if (spotifyLogoutBtn) spotifyLogoutBtn.style.setProperty('display', 'none', 'important');

        startYouTubePolling();
    } else {
        if (widgetHeader) widgetHeader.textContent = 'Spotify';
        if (spotifyLogoutBtn) spotifyLogoutBtn.style.removeProperty('display');
        
        if (window.SpotifyAuth && window.SpotifyAuth.hasStoredSession()) {
            if (spotifyAuthPrompt) spotifyAuthPrompt.style.setProperty('display', 'none', 'important');
            if (spotifyPlayerContainer) spotifyPlayerContainer.style.setProperty('display', 'flex', 'important');
        } else {
            if (spotifyAuthPrompt) spotifyAuthPrompt.style.setProperty('display', 'flex', 'important');
            if (spotifyPlayerContainer) spotifyPlayerContainer.style.setProperty('display', 'none', 'important');
        }

        updatePlayButtonIcon(false);
    }
}

/**
 * 再生中のYouTubeタブを取得する
 * @returns {Promise<chrome.tabs.Tab|null>} YouTubeのタブオブジェクト
 */
async function getYouTubeTab() {
    return new Promise((resolve) => {
        if (typeof chrome === 'undefined' || !chrome.tabs) {
            resolve(null);
            return;
        }
        chrome.tabs.query({ url: "*://*.youtube.com/*" }, (tabs) => {
            if (tabs && tabs.length > 0) {
                const activeTab = tabs.find(t => t.active) || tabs.find(t => t.audible) || tabs[0];
                resolve(activeTab);
            } else {
                resolve(null);
            }
        });
    });
}

/**
 * YouTubeタブでスクリプトを実行する
 * @param {Function} func 実行する関数
 * @returns {Promise<any>} 実行結果
 */
async function executeOnYouTube(func) {
    if (!canControlYouTube()) {
        window.showNotification?.('YouTube操作に必要な拡張権限がありません。', 'warning');
        return null;
    }

    const tab = await getYouTubeTab();
    if (!tab) return null;
    
    return new Promise((resolve) => {
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: func
        }, (results) => {
            if (chrome.runtime?.lastError) {
                console.warn('YouTubeタブの操作に失敗しました:', chrome.runtime.lastError.message);
                resolve(null);
                return;
            }
            if (results && results[0]) {
                resolve(results[0].result);
            } else {
                resolve(null);
            }
        });
    });
}

/**
 * YouTubeの再生状態を定期的に取得するポーリングを開始する
 */
function startYouTubePolling() {
    updateYouTubeUI({
        title: "読込中...",
        author: "-",
        art: "",
        playing: false
    });

    const poll = async () => {
        if (getMediaMode() !== 'youtube') return;

        const tab = await getYouTubeTab();
        if (!tab) {
            updateYouTubeUI({
                title: "YouTube タブが開いていません",
                author: "YouTubeで動画を再生してください",
                art: "https://www.youtube.com/s/desktop/20fd28a4/img/favicon_144x144.png",
                playing: false
            });
            return;
        }

        const info = await executeOnYouTube(() => {
            const video = document.querySelector('video');
            if (!video) return null;

            const titleEl = document.querySelector('h1.ytd-watch-metadata') || document.querySelector('meta[name="title"]');
            const authorEl = document.querySelector('ytd-channel-name a') || document.querySelector('meta[name="author"]');
            
            const urlParams = new URLSearchParams(window.location.search);
            const videoId = urlParams.get('v');
            const artUrl = videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : '';

            return {
                title: titleEl?.textContent?.trim() || document.title.replace(" - YouTube", ""),
                author: authorEl?.textContent?.trim() || "YouTube",
                art: artUrl,
                playing: !video.paused
            };
        });

        if (info) {
            updateYouTubeUI(info);
        } else {
            updateYouTubeUI({
                title: tab.title.replace(" - YouTube", ""),
                author: "YouTube",
                art: "https://www.youtube.com/s/desktop/20fd28a4/img/favicon_144x144.png",
                playing: false
            });
        }
    };

    poll();
    mediaPollInterval = setInterval(poll, 2000);
}

/**
 * YouTubeの情報をUIに反映する
 * @param {Object} info 再生情報のオブジェクト
 */
function updateYouTubeUI(info) {
    const trackEl = document.getElementById('spotify-track');
    const artistEl = document.getElementById('spotify-artist');
    const artImg = document.getElementById('spotify-art');

    if (trackEl) trackEl.textContent = info.title;
    if (artistEl) artistEl.textContent = info.author;
    if (artImg) {
        artImg.src = info.art || 'https://www.youtube.com/s/desktop/20fd28a4/img/favicon_144x144.png';
        artImg.style.display = 'block';
    }

    updatePlayButtonIcon(info.playing);
}

/**
 * 再生・一時停止ボタンのアイコンを更新する
 * @param {boolean} isPlaying 再生中かどうか
 */
function updatePlayButtonIcon(isPlaying) {
    const playBtn = document.getElementById('spotify-play-btn');
    const playIcon = document.getElementById('spotify-play-icon');
    if (playBtn && playIcon) {
        playBtn.setAttribute('data-playing', isPlaying ? 'true' : 'false');
        playIcon.textContent = isPlaying ? '⏸︎' : '▶︎';
    }
}

/**
 * YouTubeの再生状態を切り替える
 */
async function toggleYouTubePlay() {
    const tab = await getYouTubeTab();
    if (!tab) {
        window.showNotification("YouTube のタブが見つかりません。新規に開きます。", "info");
        if (typeof chrome !== 'undefined' && chrome.tabs) {
            chrome.tabs.create({ url: "https://www.youtube.com" });
        }
        return;
    }

    executeOnYouTube(() => {
        const video = document.querySelector('video');
        if (video) {
            if (video.paused) {
                video.play();
                return { paused: false };
            } else {
                video.pause();
                return { paused: true };
            }
        }
        return null;
    }).then(res => {
        if (res) updatePlayButtonIcon(!res.paused);
    });
}

/**
 * YouTubeのメディアコントロール（次へ/前へ）を実行する
 * @param {string} action 'next' または 'prev'
 */
async function controlYouTube(action) {
    const tab = await getYouTubeTab();
    if (!tab) return;

    if (action === 'next') {
        executeOnYouTube(() => {
            const nextBtn = document.querySelector('.ytp-next-button');
            if (nextBtn) nextBtn.click();
        });
    } else if (action === 'prev') {
        executeOnYouTube(() => {
            const video = document.querySelector('video');
            if (video) {
                if (video.currentTime > 5) {
                    video.currentTime = 0;
                } else {
                    window.history.back();
                }
            }
        });
    }
}
})();
