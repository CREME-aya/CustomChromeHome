// ==========================================
// initSidebar — サイドバー開閉ロジック
// ==========================================
(function() {
window.initSidebar = initSidebar;

/**
 * サイドバーのイベントリスナーを初期化する
 */
function initSidebar() {
    const menuBtn = document.getElementById('menu-btn');
    const closeSidebarBtn = document.getElementById('close-sidebar-btn');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebar-overlay');

    if (!menuBtn || !closeSidebarBtn || !sidebar) return;

    /**
     * サイドバーの開閉状態をトグルする
     */
    function toggleSidebar() {
        // サイドバー本体とオーバーレイを同じタイミングで開閉する。
        sidebar.classList.toggle('hidden');
        sidebarOverlay?.classList.toggle('hidden');
    }

    menuBtn.addEventListener('click', toggleSidebar);
    closeSidebarBtn.addEventListener('click', toggleSidebar);
    sidebarOverlay?.addEventListener('click', toggleSidebar);

    // 他のinit関数からサイドバーを閉じるために公開
    window._toggleSidebar = toggleSidebar;
}
})();
